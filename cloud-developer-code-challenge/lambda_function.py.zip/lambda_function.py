import json
import boto3

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('MyTable')

# Initialize the EventBridge client
eventbridge = boto3.client('events')

def lambda_handler(event, context):
    # Get the game session request events from the event bus
    events = event['detail']['gameSessionRequestEvents']

    # Extract the information from the requested and started events
    requested_event = next((e for e in events if e['detail-type'] == 'game-session-request.requested'), None)

    if not requested_event:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing game session request or started event')
        }

    # Extract the relevant information from the requested and started events
    hostname = requested_event['detail']['gameDetails']['hostname']
    players = requested_event['detail']['gameDetails']['players']
    game_map = requested_event['detail']['gameDetails']['map']
    mode = requested_event['detail']['gameDetails']['mode']

    # Record the information in the DynamoDB table
    table.put_item(
        Item={
            'hostname': hostname,
            'players': players,
            'map': game_map,
            'mode': mode
        }
    )

    # Check if the information is already recorded in the table
    response = table.get_item(
        Key={
            'hostname': hostname
        }
    )

    if response['Item']:
        # Send the finished event to the event bus
        eventbridge.put_events(
            Entries=[
                {
                    'Source': 'my-event-bus',
                    'DetailType': 'game-session-request.finished',
                    'Detail': json.dumps(event),
                }
            ]
        )
    else:
        # Send the failed event to the event bus
        eventbridge.put_events(
            Entries=[
                {
                    'Source': 'my-event-bus',
                    'DetailType': 'game-session-request.failed',
                    'Detail': json.dumps(event),
                }
            ]
        )

    return {
        'statusCode': 200,
        'body': json.dumps('Game session request processed')
    }

